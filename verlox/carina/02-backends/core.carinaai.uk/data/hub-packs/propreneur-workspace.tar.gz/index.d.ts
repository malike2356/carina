export { propreneurWorkspaceSkills } from './skills.js';
//# sourceMappingURL=index.d.ts.map