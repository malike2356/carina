import type { PackSkillInput } from '../../pack-types.js';
export declare const propreneurWorkspaceSkills: PackSkillInput[];
//# sourceMappingURL=skills.d.ts.map