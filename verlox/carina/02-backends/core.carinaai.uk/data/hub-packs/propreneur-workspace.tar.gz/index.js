export { propreneurWorkspaceSkills } from './skills.js';
//# sourceMappingURL=index.js.map