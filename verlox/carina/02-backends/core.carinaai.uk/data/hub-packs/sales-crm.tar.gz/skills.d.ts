import type { PackSkillInput } from '../../pack-types.js';
export declare const salesCrmSkills: PackSkillInput[];
//# sourceMappingURL=skills.d.ts.map