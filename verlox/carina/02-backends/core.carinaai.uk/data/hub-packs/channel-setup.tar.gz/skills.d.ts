import type { PackSkillInput } from '../../pack-types.js';
export declare const channelSetupSkills: PackSkillInput[];
//# sourceMappingURL=skills.d.ts.map