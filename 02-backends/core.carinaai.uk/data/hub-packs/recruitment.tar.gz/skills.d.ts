import type { PackSkillInput } from '../../pack-types.js';
export declare const recruitmentSkills: PackSkillInput[];
//# sourceMappingURL=skills.d.ts.map