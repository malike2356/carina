import type { PackSkillInput } from '../../pack-types.js';
export declare const capabilitiesOpsSkills: PackSkillInput[];
//# sourceMappingURL=skills.d.ts.map