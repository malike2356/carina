import type { PackSkillInput } from '../../pack-types.js';
export declare const legalUkSkills: PackSkillInput[];
//# sourceMappingURL=skills.d.ts.map