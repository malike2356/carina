import type { PackSkillInput } from '../../pack-types.js';
export declare const automationSkills: PackSkillInput[];
//# sourceMappingURL=skills.d.ts.map