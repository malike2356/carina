import type { PackSkillInput } from '../../pack-types.js';
export declare const cmsOpsSkills: PackSkillInput[];
//# sourceMappingURL=skills.d.ts.map