import type { PackSkillInput } from '../../pack-types.js';
export declare const marketingOpsSkills: PackSkillInput[];
//# sourceMappingURL=skills.d.ts.map