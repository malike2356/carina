import type { PackSkillInput } from '../../pack-types.js';
export declare const financeSkills: PackSkillInput[];
//# sourceMappingURL=skills.d.ts.map