import type { PackSkillInput } from '../../pack-types.js';
export declare const dataScienceSkills: PackSkillInput[];
//# sourceMappingURL=skills.d.ts.map