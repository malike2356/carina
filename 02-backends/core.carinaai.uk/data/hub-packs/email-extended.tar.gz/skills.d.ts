import type { PackSkillInput } from '../../pack-types.js';
export declare const emailExtendedSkills: PackSkillInput[];
//# sourceMappingURL=skills.d.ts.map