import type { PackSkillInput } from '../../pack-types.js';
export declare const mlopsSkills: PackSkillInput[];
//# sourceMappingURL=skills.d.ts.map