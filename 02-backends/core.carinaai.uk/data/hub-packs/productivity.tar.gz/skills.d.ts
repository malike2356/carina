import type { PackSkillInput } from '../../pack-types.js';
export declare const productivitySkills: PackSkillInput[];
//# sourceMappingURL=skills.d.ts.map