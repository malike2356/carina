import type { PackSkillInput } from '../../pack-types.js';
export declare const meetingOpsSkills: PackSkillInput[];
//# sourceMappingURL=skills.d.ts.map