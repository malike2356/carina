import type { PackSkillInput } from '../../pack-types.js';
export declare const operatorDailySkills: PackSkillInput[];
//# sourceMappingURL=skills.d.ts.map