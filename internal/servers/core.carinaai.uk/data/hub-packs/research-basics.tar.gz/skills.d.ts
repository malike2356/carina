import type { PackSkillInput } from '../../pack-types.js';
export declare const researchBasicsSkills: PackSkillInput[];
//# sourceMappingURL=skills.d.ts.map