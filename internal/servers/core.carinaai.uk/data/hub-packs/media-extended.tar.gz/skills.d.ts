import type { PackSkillInput } from '../../pack-types.js';
export declare const mediaExtendedSkills: PackSkillInput[];
//# sourceMappingURL=skills.d.ts.map