import type { PackSkillInput } from '../../pack-types.js';
export declare const devopsSkills: PackSkillInput[];
//# sourceMappingURL=skills.d.ts.map