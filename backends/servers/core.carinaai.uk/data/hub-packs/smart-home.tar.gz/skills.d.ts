import type { PackSkillInput } from '../../pack-types.js';
export declare const smartHomeSkills: PackSkillInput[];
//# sourceMappingURL=skills.d.ts.map