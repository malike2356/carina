import type { PackSkillInput } from '../../pack-types.js';
export declare const creativeBasicsSkills: PackSkillInput[];
//# sourceMappingURL=skills.d.ts.map