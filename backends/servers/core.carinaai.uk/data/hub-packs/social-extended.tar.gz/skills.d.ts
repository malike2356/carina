import type { PackSkillInput } from '../../pack-types.js';
export declare const socialExtendedSkills: PackSkillInput[];
//# sourceMappingURL=skills.d.ts.map